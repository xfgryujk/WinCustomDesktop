﻿#pragma once


static const TCHAR APPNAME[] = _T("$safeprojectname$");

class Config final
{
public:
	int m_someConfig = 0;


	Config();
	void LoadConfig(LPCWSTR path);
};

extern Config g_config;
