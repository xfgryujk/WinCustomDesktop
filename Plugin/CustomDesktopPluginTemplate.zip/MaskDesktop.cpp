﻿#include "stdafx.h"
#include "$safeprojectname$.h"
#include <CDEvents.h>
#include <CDAPI.h>
#include "Config.h"


$safeprojectname$::$safeprojectname$(HMODULE hModule) : 
	m_module(hModule)
{
	// TODO 监听事件
	cd::g_postDrawBackgroundEvent.AddListener(std::bind(&$safeprojectname$::OnPostDrawBackground, this, std::placeholders::_1), m_module);
	cd::g_postDrawIconEvent.AddListener(std::bind(&$safeprojectname$::OnPostDrawIcon, this, std::placeholders::_1), m_module);

	cd::ExecInMainThread([this]{
		// TODO 完成在DllMain不能完成的初始化（比如启动线程）
	});
	
	//cd::RedrawDesktop();
}

bool $safeprojectname$::OnPostDrawBackground(HDC& hdc)
{
	// TODO 添加在背景层的绘制代码

	return true;
}

bool $safeprojectname$::OnPostDrawIcon(HDC& hdc)
{
	// TODO 添加在图标层之上的绘制代码

	return true;
}
