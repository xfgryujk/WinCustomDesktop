﻿#pragma once


class $safeprojectname$ final
{
public:
	$safeprojectname$(HMODULE hModule);

private:
	HMODULE m_module;


	bool OnPostDrawBackground(HDC& hdc);
	bool OnPostDrawIcon(HDC& hdc);
};
