﻿#include "stdafx.h"
#include "Config.h"
#include <CDAPI.h>


Config g_config;


Config::Config()
{
	LoadConfig((cd::GetPluginDir() + L"\\Data\\$safeprojectname$.ini").c_str());
}

void Config::LoadConfig(LPCWSTR path)
{
	// TODO：读取设置
	m_someConfig = GetPrivateProfileIntW(APPNAME, L"SomeConfig", m_someConfig, path);
}
